__turbopack_load_page_chunks__("/_app", [
  "static/chunks/93be2d02e1665d48.js",
  "static/chunks/8ba003cd4a8b773d.js",
  "static/chunks/turbopack-c7ae8078d730d180.js"
])
