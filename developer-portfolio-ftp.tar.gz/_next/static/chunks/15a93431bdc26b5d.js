__turbopack_load_page_chunks__("/_error", [
  "static/chunks/4fe2e82085aad40b.js",
  "static/chunks/8ba003cd4a8b773d.js",
  "static/chunks/turbopack-4c3db370fe4a2e09.js"
])
